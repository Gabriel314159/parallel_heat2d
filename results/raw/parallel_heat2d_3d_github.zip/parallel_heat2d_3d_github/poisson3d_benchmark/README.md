# 独立 3D Poisson 基准

在长方体域中求解 \(-\Delta\phi=f\)，六个面采用齐次 Dirichlet 条件 \(\phi=0\)。网格参数 \((n_x,n_y,n_z)\) 是内部未知节点数。程序以矩阵无关的方式应用七点差分模板，用无预条件 CG 求解。MPI 在 \(x,y\) 方向分块，每个 rank 保留完整的 \(z\) 方向。每轮 CG 交换一次搜索方向的 halo，并做两次全局求和。OpenMP 分担 rank 内的网格循环和局部内积。

## 与 2D 实验对应的配置

2D 数据源：[Vanda 原始结果及说明](https://github.com/Gabriel314159/parallel_heat2d/tree/43ad716291c270eb6cfbbb2d99ccd8a374f8fcc4/results/raw)。固定规模 GPU 实验和网格扫描均测了 1 张和 2 张 A40，每 rank 用 36 个 OpenMP 线程。网格扫描还有相同 MPI/线程配置的 CPU 结果。

| 实验 | 3D 配置 |
|---|---|
| 正确性 | 已知连续解的加密测试，精确离散解，不均匀分块下的逐点串行／MPI 对照，以及 1／2 GPU 验证 |
| 串行规模 | 单核和单位立方体，每轴 32、48、64、96、128 个内部节点 |
| MPI 强扩展 | \(128^3\) 个内部节点，1、2、4、8、16、32、64、128、256 ranks，每 rank 1 线程。另记纯串行和开启 OpenMP 编译的单线程串行参考 |
| OpenMP 强扩展 | 同一 \(128^3\) 网格，单 rank 分别用 1、2、4、8、16、32、36、64、72 线程 |
| 256 核混合布局 | 同一 \(128^3\) 网格，\(P\times T\) 为 \(256\times1,128\times2,64\times4,32\times8,16\times16,8\times32,4\times64\) |
| MPI 弱扩展 | 一个作业内完成 1、4、9、16、36、64、144、256 ranks。每 rank \(32^3\) 个内部节点、1 线程，间距固定为 \(1/33\)，扩大 \(x,y\) 方向，深度固定。基准为单 rank MPI |
| 分块与通信 | 256 ranks，每 rank 1 线程。比较行分块／二维分块与阻塞／重叠交换的四种组合。使用 \(256\times1024\times32\) 网格，使行分块有 4 行/rank 和可用于重叠的内部点 |
| CPU/GPU 随规模变化 | 依次测试 \(64^3,128^3,192^3,256^3\)。每个网格同时比较 \(1\times36\) CPU 与同布局 1 张 A40，以及 \(2\times36\) CPU 与同布局 2 张 A40 |

固定三维问题沿用同一 RHS 构造法、零初值和 \(10^{-8}\) CG 容差，每种配置预热一次，正式测量五次。性能 RHS 是平滑正弦分量加按全局索引生成的确定性扰动，更改分块不改变 RHS。2D 数据来自整个时间推进过程，3D 数据来自一次独立线性求解，没有时间步数。比较延展性时分别报告总求解时间和单轮摊销成本。

CPU 的新分配在计时前使用并行 first-touch。2D 原始版与 first-touch 重跑间的差异已有独立记录。此包的控制实验为单节点 64 核混合布局，以及固定 64 ranks 分布到 1、2、4 个节点；可在 CPU 作业以 `qsub -v POISSON3D_CONTROLS=1 ...` 启用，或用 `--include-controls --dry-run` 查看。2D 的插槽放置与主频观测是原求解器的专门控制，3D 不复跑这些观测。

## 使用方法

在解包后的目录执行。需要 C++17、Python 3.9 或更新版本。仅在本地运行串行版：

```bash
POISSON3D_SERIAL_ONLY=1 CXX=c++ bash build.sh
python3 run_experiments.py verify --serial-only
./build/poisson3d_serial --nx 32 --ny 32 --nz 32 --rhs benchmark
```

在有 GCC、Open MPI 和 OpenMP 的 Linux 环境，可用 `bash build.sh` 构建 CPU 版本，再运行 `python3 run_experiments.py verify`。验证检查阶数、显式重算的真实残差，以及分块和 overlap 的逐点误差。

Vanda 作业默认在计算节点构建。CPU 作业沿用项目的 GCC/Open MPI 模块。GPU 作业用同一 NVHPC/HPC-X 工具链构建 CPU 和 GPU 版本，并在同一个 GPU 节点上计时。把 `your_project` 替换成分配的 PBS 项目名：

```bash
python3 run_experiments.py one-node --dry-run
python3 run_experiments.py four-nodes --dry-run
python3 run_experiments.py gpu --dry-run

qsub -P your_project one_node.pbs
qsub -P your_project four_nodes_checked.pbs
qsub -P your_project two_gpus.pbs
```

`four_nodes_checked.pbs` 是取得报告中多节点数据的版本，使用 `mpi_checked/` 中的运行脚本。它在同一分配内先检查四节点启动和绑定，再测量正式配置。`two_gpus.pbs` 一次取得一张和两张卡的数据。`one_gpu.pbs` 只需申请一张卡，运行其 CPU/GPU 对照子集。

CPU 四节点配置每节点使用 64 个活跃物理核，OpenMP 单 rank 扫描可使用节点的 72 个核。Vanda 的跨插槽 rank 使用项目记录的物理核编号顺序来设置 `OMP_PLACES`；作业验证实际线程数、节点数和绑核后记录数据。GPU 运行时每 rank 使用一张设备。同节点两个 MPI rank 通过主机缓冲区进行阻塞 halo 交换。向量保留在 GPU 上，每轮全局归约在 MPI 进程间进行。计时前先验证 GPU 执行位置，并用已知离散解和宽频 RHS 与 CPU 结果逐点比较。双 rank 验证覆盖两个 halo 方向。

## 结果和指标

结果在 `results/<PBS job ID>/`，包括原始 CSV、验证记录、运行命令、节点、模块及二进制指纹的 JSON。用同一批次的 CSV 汇总：

```bash
python3 summarize.py results/JOB_1/one-node.csv results/JOB_2/four-nodes.csv \
    results/JOB_3/gpu.csv > summary.csv
```

报告排除预热并以中位数比较正式测量。强扩展的加速比从纯串行算起，弱扩展效率从同一系列的一核 MPI 算起。GPU 的两个比分别是相同 rank/线程配置的 CPU 对 GPU、以及单卡对双卡。双卡加速比对应从 \(1\times36\) 到 \(2\times36\) 的整套执行配置。

- `solve_s` 包括初始残差范数、CG 迭代和通信。MPI 取 rank 最大值。RHS 构造和求解后的残差检查在计时段外。
- `solve_total_s` 还包括 GPU 设备数组的准备和取回。CPU 此值等于 `solve_s`。GPU 加速比用 `solve_total_s`，迭代成本用 `solve_s_per_iteration`。
- `halo_s` 包括双卡的主机中转。CPU overlap 测发送接收启动和等待耗时。`halo_device_copy_s` 单记双卡 halo 的主机／设备传输；`reduction_s`／`reduction_min_s` 是 rank 上归约耗时的最大／最小值，可能包含等待时间。这些 rank 极值分别报告。
- `N` 为 \(n_xn_yn_z\)。非零元数为 \(7N-2(n_xn_y+n_xn_z+n_yn_z)\)。用对数坐标展示时间、规模或核数。
