# DSA5208 Project 3: Three-Dimensional Poisson Solver and Model A

This source package contains the standalone 3D Poisson solver used in the Vanda performance experiments and a demonstration that uses its solution to drive pigment transport in Model A.

| Path | Role |
| --- | --- |
| `poisson3d_benchmark/` | Matrix-free seven-point Poisson solver with serial, MPI/OpenMP, and OpenMP target offload implementations. Includes validation, PBS job scripts, and CSV summarization. |
| `model_a_poisson_bridge/` | Builds the shared Poisson source and Model A, exports a streamfunction, and checks the resulting pigment transport. |
| `model_a_poisson_bridge/model_a/` | Project source at `6f53d23b06227deabef691b31bd4edbc7308edcb`, with the fixed-flow input added to the 3D serial and MPI drivers. Its `docs/` directory contains the model design. |
| `results/vanda/` | Raw single-node, multi-node, and A40 measurements, a combined summary, numerical validation, and job metadata. |
| `results/model_a_bridge/` | Local validation results for the cubic serial example and the rectangular MPI/OpenMP example. Includes input streamfunctions and final pigment fields. |

## Included results

The three Vanda jobs completed successfully. The raw CSV files contain 25 single-node CPU configurations, 23 multi-node suite configurations, and 16 CPU/GPU configurations. Each configuration has one warm-up and five measured repetitions. `results/vanda/summary.csv` reports medians and measurement ranges. The accompanying JSON files record commands, modules, binary hashes, and numerical validation. Compute-node labels, GPU UUIDs, and user home paths were generalized for sharing. `results/vanda/jobs.json` preserves the relevant PBS completion fields.

Regenerate the summary from the package root with:

```bash
python3 poisson3d_benchmark/summarize.py \
    results/vanda/one-node.csv results/vanda/four-nodes.csv results/vanda/gpu.csv
```

`results/model_a_bridge/unit-cube-serial/` contains the default \(33^3\) run. `results/model_a_bridge/rectangular-4ranks-2threads/` contains the \(33\times25\times17\) test with overlapping halo exchange. The latter used a \(1\times0.8\times0.5\) domain and produced identical concentrations in the serial and four-rank runs. Both examples advanced 50 pigment steps and include the pure-diffusion reference. These are local correctness results. The Vanda performance data correspond to the independent Poisson solver.

## Run the coupled demonstration

From the extracted package root, run the following with Python 3.8 or newer, CMake 3.16 or newer, and a C++17 compiler.

```bash
python3 model_a_poisson_bridge/run_bridge.py
```

The demonstration solves \(-\Delta_h\psi=f\) once on \(32^3\) interior vertices of a unit cube, using a manufactured discrete solution and \(\psi=0\) on all six walls. Model A reads the exported streamfunction and reconstructs face velocities from differences in the horizontal directions on each depth layer. The velocity is fixed in time with a zero vertical component. Model A advances pigment on \(33^3\) cells for 50 steps. The fixed-flow and zero-flow runs use the same initial pigment field and time step, so the output compares advection with diffusion against diffusion alone at the same physical time.

With MPI and OpenMP installed, run the additional serial/MPI comparison using four ranks and two threads per rank:

```bash
python3 model_a_poisson_bridge/run_bridge.py --ranks 4 --threads 2
```

The bundled rectangular example uses:

```bash
python3 model_a_poisson_bridge/run_bridge.py --cells 33 25 17 \
    --lengths 1 0.8 0.5 --ranks 4 --threads 2 --exchange overlap
```

The runner prints its output path. `bridge-summary.json` records the Poisson residual, concentration comparison, mass conservation, wall-normal velocity, and discrete divergence. `fixed-serial.csv` and `diffusion-serial.csv` contain the final concentration fields. The MPI comparison also writes `fixed-mpi.csv`. The bridge exports and broadcasts the vertex field once and supports up to one million interior vertices for these demonstrations.

To run the MPI comparison on Vanda, submit from the bridge directory within this package. Substitute your allocation for `YOUR_PROJECT`.

```bash
cd model_a_poisson_bridge
qsub -P YOUR_PROJECT bridge.pbs
```

## Run the Poisson validation and benchmarks

From the package root, run these commands to build and validate the standalone serial solver. On Vanda, `python3` 3.9 or newer and the compiler modules specified in the PBS files are required for the full experiments.

```bash
cd poisson3d_benchmark
POISSON3D_SERIAL_ONLY=1 bash build.sh build
python3 run_experiments.py verify --serial-only
```

From `poisson3d_benchmark/` on Vanda, submit the relevant jobs:

```bash
qsub -P YOUR_PROJECT one_node.pbs
qsub -P YOUR_PROJECT four_nodes_checked.pbs
qsub -P YOUR_PROJECT two_gpus.pbs
```

The benchmark corresponds to the Vanda CPU jobs `1559053.stdct-mgmt-02` and `1563439.stdct-mgmt-02` and GPU job `1559087.stdct-mgmt-02`. These jobs time a single standalone Poisson solve per run. The Model A demonstration is a separate workload whose time-stepping loop uses velocities reconstructed from the initialization solve. See the README in each directory for the output format and timing definitions.

The original Model A benchmark scripts are available under `model_a_poisson_bridge/model_a/hpc/jobs/`. They run the original Model A flow mode from that directory's project root. The results in this package cover the standalone Poisson benchmark and the fixed-flow validation examples.
