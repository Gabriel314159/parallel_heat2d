# Model A 与 3D Poisson 的接入

本包把独立 3D Poisson 求解器输出的流函数接入 Model A 的颜料输运。默认在单位立方体上使用 \(33^3\) 个颜料单元，推进 50 步。脚本在相同初始条件、时间步和物理时刻下比较固定流场与纯扩散，也可以用 MPI + OpenMP 再跑一次固定流场来核对并行结果。

## 计算过程

1. `poisson3d_serial` 在 \(32^3\) 个内部顶点上解 \(-\Delta_h\psi=f\)，六个面上设 \(\psi=0\)。`--rhs discrete` 从已知的离散解构造右端项，便于检验求解和数据传递。
2. `run_bridge.py` 把网格和域长度写入 `fixed-psi.txt` 的文件头。`heat3d_serial` 和 `heat3d_parallel` 通过 `--fixed-psi` 读取同一份流函数。Poisson 使用顶点，颜料使用单元中心。每层在 \(z\) 方向平均上下两个顶点平面，再用 Model A 的角点差分算水平面速度。

$$
(u,v,w)=\left(\frac{\partial\psi}{\partial y},\;-\frac{\partial\psi}{\partial x},\;0\right),
\qquad
\partial_t c+\nabla\cdot(\mathbf u c-\kappa\nabla c)=0.
$$

3. MPI 由 rank 0 读取小网格的流函数，广播一次。每个 rank 生成自己分块里的各层速度。此后 Model A 在每个时间步交换浓度的 halo 并更新自己的单元，OpenMP 分担分块内的循环。
4. 固定流使用实测的面速度最大值选 CFL 时间步。纯扩散组读取零流函数，并从固定流组复用同一 \(\Delta t\)。脚本检查真残差、离散散度、壁面法向速度和浓度界限，记录总质量相对变化，并在 MPI 模式下比较全部浓度单元。

这是一个固定、随深度变化的水平流场，竖直输运来自扩散。固定流初始时刻为零，Poisson 在颜料循环之前求一次。`poisson.log` 记录这一次求解，`flow_setup_s` 记录读取和生成速度的时间，`elapsed_s` 记录颜料时间步循环。固定流运行如需快照，可以使用 Model A 的 `--snapshot-interval`。快照中的流函数、涡量及相应诊断量使用顶层数据。

## 本地运行

在解压后的目录运行。串行模式需要 Python 3.8+、CMake 3.16+ 和 C++17 编译器。MPI 模式还需要 MPI，线程数大于 1 时需要 OpenMP。

```bash
python3 run_bridge.py
```

也可以用一个不均匀分块的长方体检查 MPI 接入。

```bash
python3 run_bridge.py --cells 33 25 17 --lengths 1 0.8 0.5 \
    --ranks 4 --threads 2 --exchange overlap
```

`--cells` 是颜料单元数。每个方向的 Poisson 内部顶点数少 1，间距对应。Poisson 的文件导出功能限制内部顶点总数为 100 万，这个工作流适用于小网格的模型验证和可视化。

## 在 Vanda 运行

把 `parallel_heat2d_3d_github.zip` 上传到 Vanda 主目录并整个解压，保留两个源码目录的相对位置。把 `YOUR_PROJECT` 替换成你的 Vanda 项目名。作业申请单节点 8 核，颜料输运使用 4 个 MPI 进程、每进程 2 个线程。

```bash
unzip ~/parallel_heat2d_3d_github.zip
cd parallel_heat2d_3d_github/model_a_poisson_bridge
qsub -P YOUR_PROJECT bridge.pbs
```

本地结果在 `results/run-*`，Vanda 结果在 `results/<完整作业 ID>`。运行开始时会打印目录，检查通过后会打印 `bridge-summary.json` 的完整路径。

| 文件 | 内容 |
|---|---|
| `bridge-summary.json` | Poisson 真残差、每组的计时、质量误差及浓度场差值 |
| `fixed-serial.csv` | 固定流场下的最终浓度 |
| `diffusion-serial.csv` | 同一物理时刻的纯扩散浓度 |
| `fixed-mpi.csv` | MPI + OpenMP 的固定流场最终浓度，MPI 模式生成 |
| `fixed-psi.txt` | 带网格头的流函数，供两个颜料求解器复用 |

浓度 CSV 有 `NZ × NY` 行、`NX` 列，按层从上到下、按行从北到南排列。报告中可以用统一色标对照两组的中间层和靠近顶部的一个层切片。已有独立 Poisson 的 CSV 用来报告求解器扩展性，接入实验用浓度和守恒检查展示模型行为。

## 代码来源

`model_a/` 是项目 `3d-pigment-model-a` 分支提交 `6f53d23b06227deabef691b31bd4edbc7308edcb` 的构建所需源码副本。新增 `common3d/fixed_flow.*` 负责流函数输入和面速度重建，并由 `heat3d_serial`、`heat3d_parallel` 的 `--fixed-psi` 选项调用。衔接程序与性能实验从同一份 `../poisson3d_benchmark/poisson3d.cpp` 构建求解器。
