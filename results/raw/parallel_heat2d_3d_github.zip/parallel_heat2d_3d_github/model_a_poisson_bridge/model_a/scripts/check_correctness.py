#!/usr/bin/env python3
"""Run the correctness cases of experiments/correctness.json and check them.

For every run, the serial solver is run on the resolved problem and checked
(docs/experiment_plan.md, "Correctness"):
  - mass conservation: relative mass change <= mass_conservation_rtol,
  - constant case: the field stays at the background value,
  - cosine_decay: agreement with the exact discrete solution
    (cosine_decay_discrete_rtol); the error against the continuous solution is
    reported separately, as discretization error.

If heat_serial_omp is built, its field is compared with the serial one too.

Each run also names a parallel configuration. Once heat_parallel is built,
its final field is compared cell by cell with the serial one
(serial_parallel_atol / serial_parallel_rtol). Until then those comparisons
are reported as skipped; --serial-only skips them silently.

An experiment file with "model": "3d" (experiments/correctness_3d.json) runs
the 3D pigment model instead: heat3d_serial against heat3d_parallel, with the
whole 3D field compared cell by cell.

Exit status: 0 if every check passed, 1 otherwise.

Example:
    python3 scripts/check_correctness.py --serial-only
    python3 scripts/check_correctness.py --experiment experiments/correctness_3d.json
"""

from __future__ import annotations

import argparse
import json
import shlex
import sys
from pathlib import Path

from heat2d_tools import (MODELS, REPO, SHARED_KEYS, deep_merge, executable, load_json, model_of, problem_args,
                          read_field_csv,
                          resolve_base, run_solver)


def resolve_runs(experiment_path: Path) -> list[dict]:
    """Defaults, then the experiment-level overrides, then each run's overrides."""
    experiment = load_json(experiment_path)
    base = resolve_base(experiment_path)
    runs = []
    for run in experiment["runs"]:
        resolved = deep_merge(base, {key: run[key] for key in SHARED_KEYS if key in run})
        resolved["name"] = run["name"]
        runs.append(resolved)
    return runs


def layout_kind(ranks: int, threads: int) -> str:
    """Which of the compared layouts of experiments 1 to 3 a run exercises."""
    if ranks == 1 and threads == 1:
        return "one rank, one thread"
    if threads == 1:
        return "MPI only"
    if ranks == 1:
        return "OpenMP only"
    return "MPI + OpenMP"


def parallel_args(execution: dict) -> list[str]:
    args = ["--decomp", execution["decomposition"], "--exchange", execution["exchange"]]
    if execution.get("process_grid"):
        py, px = execution["process_grid"]
        args += ["--py", str(py), "--px", str(px)]
    return args


def max_field_difference(a: list[list[float]], b: list[list[float]], atol: float, rtol: float) -> tuple[float, bool]:
    if len(a) != len(b) or any(len(ra) != len(rb) for ra, rb in zip(a, b)):
        return float("inf"), False
    worst = 0.0
    within = True
    for row_a, row_b in zip(a, b):
        for x, y in zip(row_a, row_b):
            difference = abs(x - y)
            worst = max(worst, difference)
            within = within and difference <= atol + rtol * abs(y)
    return worst, within


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--experiment", default=str(REPO / "experiments/correctness.json"))
    parser.add_argument("--build-dir", default=str(REPO / "build"))
    parser.add_argument("--output-dir", help="where fields are written (default: the experiment's output.directory)")
    parser.add_argument("--serial-only", action="store_true", help="skip the serial/parallel comparisons")
    parser.add_argument("--launcher", default="mpiexec -n {ranks}", help="MPI launch command; {ranks} is replaced")
    parser.add_argument("--run", action="append", help="only this run name (may be repeated)")
    parser.add_argument("--exchange", choices=["blocking", "overlap"],
                        help="use this exchange in every parallel case (blocking for the GPU build)")
    parser.add_argument("--require-gpu", action="store_true", help="fail parallel runs not solved on a GPU")
    args = parser.parse_args()

    experiment_path = Path(args.experiment).resolve()
    experiment = load_json(experiment_path)
    checks = experiment["checks"]
    model = MODELS[model_of(experiment)]
    runs = resolve_runs(experiment_path)
    if args.run:
        runs = [run for run in runs if run["name"] in args.run]
    if args.exchange:
        for run in runs:
            run["execution"]["exchange"] = args.exchange

    serial = executable(args.build_dir, model["serial"])
    parallel_path = Path(args.build_dir) / model["parallel"]
    parallel_built = parallel_path.is_file()

    report = []
    failures = 0
    for run in runs:
        name = run["name"]
        problem = run["problem"]
        out_dir = Path(args.output_dir or REPO / run["output"]["directory"])
        out_dir.mkdir(parents=True, exist_ok=True)
        results = []  # (check, passed or None for skipped/info, detail)

        serial_csv = out_dir / f"{name}_serial.csv"
        try:
            summary = run_solver([str(serial), *problem_args(problem), "--output", str(serial_csv)])
        except (RuntimeError, ValueError) as error:
            results.append(("serial run", False, str(error)))
            summary = None

        if summary is not None:
            tol = checks["mass_conservation_rtol"]
            results.append(("mass conservation", summary["mass_error"] <= tol,
                            f"relative change {summary['mass_error']:.2e} (tolerance {tol:.0e})"))

            if problem["case"] == "constant" and checks.get("constant_field_invariance"):
                c0 = problem["background"]
                field = read_field_csv(serial_csv)
                deviation = max(abs(value - c0) for row in field for value in row)
                tol = 1e-12 * max(1.0, abs(c0))
                results.append(("constant field", deviation <= tol, f"max |c - {c0:g}| = {deviation:.2e}"))

            if problem["case"] == "cosine_decay":
                tol = checks["cosine_decay_discrete_rtol"]
                error = summary["cosine_discrete_error"]
                results.append(("cosine vs exact discrete", error <= tol, f"{error:.2e} (tolerance {tol:.0e})"))
                results.append(("cosine vs continuous", None,
                                f"{summary['cosine_continuous_error']:.2e} (discretization error, reported only)"))

            # heat_serial_omp, the second one-core reference, must give the serial field (2D only).
            serial_omp = Path(args.build_dir) / model["serial_omp"] if "serial_omp" in model else None
            if serial_omp is None:
                pass
            elif serial_omp.is_file():
                omp_csv = out_dir / f"{name}_serial_omp.csv"
                try:
                    run_solver([str(serial_omp), *problem_args(problem), "--output", str(omp_csv)])
                    worst, within = max_field_difference(read_field_csv(omp_csv), read_field_csv(serial_csv),
                                                         checks["serial_parallel_atol"], checks["serial_parallel_rtol"])
                    results.append(("heat_serial_omp vs serial", within, f"max |difference| = {worst:.2e}"))
                except (RuntimeError, ValueError) as error:
                    results.append(("heat_serial_omp run", False, str(error)))
            else:
                results.append(("heat_serial_omp vs serial", None, "skipped: heat_serial_omp is not built"))

            execution = run["execution"]
            if execution.get("backend") == "parallel" and not args.serial_only:
                if not parallel_built:
                    results.append(("serial vs parallel", None, f"skipped: {model['parallel']} is not built yet"))
                else:
                    ranks = int(execution["mpi_ranks"])
                    threads = int(execution["omp_threads"])
                    parallel_csv = out_dir / f"{name}_parallel.csv"
                    command = [*shlex.split(args.launcher.format(ranks=ranks)), str(parallel_path),
                               *problem_args(problem), *parallel_args(execution), "--output", str(parallel_csv)]
                    try:
                        launched = run_solver(command, threads=threads)
                        worst, within = max_field_difference(
                            read_field_csv(parallel_csv), read_field_csv(serial_csv),
                            checks["serial_parallel_atol"], checks["serial_parallel_rtol"])
                        results.append(("serial vs parallel", within,
                                        f"max |difference| = {worst:.2e} "
                                        f"({ranks} ranks x {threads} threads: {layout_kind(ranks, threads)})"))
                        # The run reports what it used. A different rank count is an error; a different
                        # thread count only means that heat_parallel was built without OpenMP.
                        if launched["mpi_ranks"] != ranks:
                            results.append(("MPI ranks", False,
                                            f"requested {ranks}, the run used {launched['mpi_ranks']}"))
                        if args.require_gpu and launched.get("poisson_device") != "gpu":
                            results.append(("Poisson solve on a GPU", False,
                                            f"it ran on {launched.get('poisson_device')!r}"))
                        if launched["omp_threads"] != threads:
                            results.append(("OpenMP threads", None,
                                            f"requested {threads}, the run used {launched['omp_threads']} "
                                            f"(is heat_parallel built without OpenMP?)"))
                    except (RuntimeError, ValueError) as error:
                        results.append(("parallel run", False, str(error)))

        exchange = run["execution"].get("exchange", "none")
        grid = f"{problem['nx']} x {problem['ny']}" + (f" x {problem['nz']}" if "nz" in problem else "")
        print(f"{name}  ({grid}, {problem['steps']} steps, case {problem['case']}, "
              f"{exchange} exchange)")
        for check, passed, detail in results:
            mark = "ok  " if passed else ("--  " if passed is None else "FAIL")
            print(f"  {mark}  {check}: {detail}")
            failures += passed is False
        report.append({"run": name, "exchange": exchange, "checks": [
            {"check": check, "passed": passed, "detail": detail} for check, passed, detail in results]})

    report_dir = Path(args.output_dir or REPO / "outputs/correctness")
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    print(f"\n{'PASS' if failures == 0 else 'FAIL'}: {failures} failed check(s); report in {report_dir / 'report.json'}")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
