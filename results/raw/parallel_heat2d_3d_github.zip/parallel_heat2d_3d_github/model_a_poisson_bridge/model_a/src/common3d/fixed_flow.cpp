#include "common3d/fixed_flow.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <stdexcept>
#include <string>

#include "common/flow.hpp"
#include "common/stability.hpp"

std::size_t fixed_psi_size(const Config3D& cfg) {
    // Same limit as the small-grid --solution export of poisson3d_serial.
    constexpr std::size_t export_limit = 1000000;
    std::size_t count = 1;
    for (const int cells : {cfg.base.nx, cfg.base.ny, cfg.nz}) {
        if (cells < 2 || static_cast<std::size_t>(cells - 1) > export_limit / count) {
            throw std::invalid_argument("--fixed-psi needs at least two cells per axis and at most 1,000,000 interior vertices");
        }
        count *= cells - 1;
    }
    return count;
}

std::vector<double> load_fixed_psi(const Config3D& cfg) {
    std::ifstream input(cfg.fixed_psi_path);
    if (!input) throw std::runtime_error("cannot open " + cfg.fixed_psi_path);

    std::string version;
    int nx, ny, nz;
    double lx, ly, lz;
    if (!(input >> version >> nx >> ny >> nz >> lx >> ly >> lz) || version != "HEAT3D_PSI_V1") {
        throw std::runtime_error("invalid streamfunction header in " + cfg.fixed_psi_path);
    }
    if (nx != cfg.base.nx - 1 || ny != cfg.base.ny - 1 || nz != cfg.nz - 1 ||
        lx != cfg.base.lx || ly != cfg.base.ly || lz != cfg.lz) {
        throw std::invalid_argument("fixed streamfunction grid or domain does not match the pigment grid");
    }
    std::vector<double> vertices(fixed_psi_size(cfg));
    for (double& value : vertices) {
        if (!(input >> value) || !std::isfinite(value)) {
            throw std::runtime_error("missing or invalid streamfunction value in " + cfg.fixed_psi_path);
        }
    }
    std::string extra;
    if (input >> extra) throw std::runtime_error("extra streamfunction values in " + cfg.fixed_psi_path);
    return vertices;
}

FixedFlow3D::FixedFlow3D(const Config3D& cfg, const Block& b, const std::vector<double>& vertices)
    : surface_psi(b.ny, b.nx), surface_zeta(b.ny, b.nx) {
    const int nx = cfg.base.nx;
    const int ny = cfg.base.ny;
    const int nz = cfg.nz;
    const double dx = cfg.base.lx / nx;
    const double dy = cfg.base.ly / ny;
    const auto vertex = [&](int row, int col, int level) {
        if (row == 0 || row == ny || col == 0 || col == nx || level == 0 || level == nz) return 0.0;
        // Model A rows and levels count down from the north wall and surface.
        const auto index = (static_cast<std::size_t>(nz - level - 1) * (ny - 1) + (ny - row - 1))
                           * (nx - 1) + col - 1;
        return vertices[index];
    };
    const auto layer_corner = [&](int row, int col, int layer) {
        return 0.5 * vertex(row, col, layer - 1) + 0.5 * vertex(row, col, layer);
    };

    Field psi(b.ny, b.nx);
    layers.reserve(nz);
    for (int layer = 1; layer <= nz; ++layer) {
        for (int i = 0; i <= b.ny; ++i) {
            for (int j = 0; j <= b.nx; ++j) {
                psi(i, j) = layer_corner(b.row_offset + i, b.col_offset + j, layer);
            }
        }
        FaceVelocities& vel = layers.emplace_back(b.ny, b.nx);
        faces_from_psi(psi, vel, dx, dy);
        double u, v;
        max_face_speeds(vel, u, v);
        u_max = std::max(u_max, u);
        v_max = std::max(v_max, v);
        for (int i = 1; i <= b.ny; ++i) {
            if (b.wall_left) wall_normal_max = std::max(wall_normal_max, std::abs(vel.east(i, 0)));
            if (b.wall_right) wall_normal_max = std::max(wall_normal_max, std::abs(vel.east(i, b.nx)));
            for (int j = 1; j <= b.nx; ++j) {
                const double div = (vel.east(i, j) - vel.east(i, j - 1)) / dx
                                 + (vel.north(i, j) - vel.north(i + 1, j)) / dy;
                max_divergence = std::max(max_divergence, std::abs(div));
            }
        }
        for (int j = 1; j <= b.nx; ++j) {
            if (b.wall_top) wall_normal_max = std::max(wall_normal_max, std::abs(vel.north(1, j)));
            if (b.wall_bottom) wall_normal_max = std::max(wall_normal_max, std::abs(vel.north(b.ny + 1, j)));
        }
        if (layer == 1) surface_psi = psi;
    }

    // Surface-layer vorticity for the existing snapshot format.
    for (int i = 0; i <= b.ny; ++i) {
        const int row = b.row_offset + i;
        if (row == 0 || row == ny) continue;
        for (int j = 0; j <= b.nx; ++j) {
            const int col = b.col_offset + j;
            if (col == 0 || col == nx) continue;
            const double mid = surface_psi(i, j);
            surface_zeta(i, j) = (2 * mid - layer_corner(row, col - 1, 1) - layer_corner(row, col + 1, 1)) / (dx * dx)
                               + (2 * mid - layer_corner(row - 1, col, 1) - layer_corner(row + 1, col, 1)) / (dy * dy);
        }
    }
}
