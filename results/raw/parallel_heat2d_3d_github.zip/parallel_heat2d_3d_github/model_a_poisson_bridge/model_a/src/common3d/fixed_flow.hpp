#pragma once

#include <cstddef>
#include <vector>

#include "common/grid.hpp"
#include "common3d/config3d.hpp"

// Interior vertices in (z, y, x) order, with x fastest and coordinates increasing.
std::size_t fixed_psi_size(const Config3D& cfg);
std::vector<double> load_fixed_psi(const Config3D& cfg);

// This rank's face velocities at each pigment layer, from one global vertex field.
struct FixedFlow3D {
    FixedFlow3D(const Config3D& cfg, const Block& block, const std::vector<double>& vertices);

    std::vector<FaceVelocities> layers;
    Field surface_psi;
    Field surface_zeta;
    double u_max = 0.0;
    double v_max = 0.0;
    double max_divergence = 0.0;
    double wall_normal_max = 0.0;
};
