// Halo exchange of the scalar field between neighbouring ranks.
// See docs/design.md, "Halo exchange".
//
// Rows are contiguous in memory and are sent directly from the field with an
// MPI vector datatype (halo rows of nx interior values). Columns are not
// contiguous: they are packed into buffers before sending and unpacked after
// receiving. The same scheme is used for blocking and overlapping exchange, so
// comparing the two changes nothing but the timing of the messages.
//
// Only interior cells are sent and only edge ghost cells are written; corner
// ghost cells are never read by the five-point update and are left alone.

#pragma once

#include <mpi.h>

#include <vector>

#include "common/grid.hpp"
#include "parallel/decomposition.hpp"

class HaloExchange {
public:
    HaloExchange(const ProcessLayout& layout, int ny, int nx);
    ~HaloExchange();
    HaloExchange(const HaloExchange&) = delete;
    HaloExchange& operator=(const HaloExchange&) = delete;

    // Blocking: start() then finish(). On return, every process halo of `c`
    // holds its neighbour's values.
    void exchange(Field& c);

    // True if some side of the block borders another rank.
    bool has_neighbours() const {
        return north_ != MPI_PROC_NULL || south_ != MPI_PROC_NULL || west_ != MPI_PROC_NULL || east_ != MPI_PROC_NULL;
    }

    // Nonblocking: post all receives, pack the columns and post all sends.
    // Until finish(), do not modify the interior of `c` or read its process halos.
    void start(Field& c);

    // Wait for all messages of start() and unpack the received columns.
    void finish(Field& c);

    // Blocking, for the corner fields psi and zeta, whose stencils also read
    // the diagonal neighbours: first the columns, then whole stored rows
    // including their ghost columns, so that the values just received from the
    // east and west neighbours travel on to the diagonal neighbours.
    void exchange_with_corners(Field& c);

private:
    void pack_columns(const Field& c);
    void unpack_columns(Field& c);

    MPI_Comm comm_;
    int north_;
    int south_;
    int west_;
    int east_;
    int ny_;
    int nx_;
    MPI_Datatype rows_;       // `halo` rows of nx interior values, stride = field stride
    MPI_Datatype full_rows_;  // `halo` whole stored rows, ghost columns included
    std::vector<double> send_west_;
    std::vector<double> send_east_;
    std::vector<double> recv_west_;
    std::vector<double> recv_east_;
    MPI_Request requests_[8];
    int pending_ = 0;
};
