#!/usr/bin/env python3
"""Build and verify the coupling of a 3D Poisson solve to Model A."""

import argparse
from array import array
import csv
import json
import math
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
EXPORT_LIMIT = 1_000_000  # the standalone solver's --solution limit


def run(command, log):
    print(shlex.join([str(arg) for arg in command]), flush=True)
    with log.open("w") as stream:
        subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)


def configure_output(path):
    if path is None:
        parent = ROOT / "results"
        parent.mkdir(exist_ok=True)
        return Path(tempfile.mkdtemp(prefix="run-", dir=parent))
    path = path.resolve()
    path.mkdir(parents=True)
    return path


def build(output, mpi):
    build_dir = output / "build"
    run([
        "cmake", "-S", ROOT, "-B", build_dir, "-DCMAKE_BUILD_TYPE=Release", "-DHEAT2D_BUILD_TESTS=OFF",
        "-DHEAT2D_ENABLE_MPI=" + ("ON" if mpi else "OFF"),
        "-DHEAT2D_ENABLE_OPENMP=" + ("ON" if mpi else "OFF"),
    ], output / "configure.log")
    targets = ["poisson3d_serial", "heat3d_serial"]
    if mpi:
        targets.append("heat3d_parallel")
    run(["cmake", "--build", build_dir, "--parallel", "4", "--target", *targets], output / "build.log")
    return build_dir / "bin"


def geometry_flags(shape, lengths):
    return [flag for axis, n, length in zip("xyz", shape, lengths)
            for flag in ("--n" + axis, str(n), "--l" + axis, repr(length))]


def generate_flow(binary, output, interiors, lengths):
    raw = output / "psi-vertices.txt"
    log = output / "poisson.log"
    run([binary, *geometry_flags(interiors, lengths), "--rhs", "discrete", "--solution", raw], log)
    stats = json.loads(log.read_text())
    if not 0 <= stats["relative_residual"] <= 1.1 * stats["tol"]:
        raise RuntimeError("the 3D Poisson solve missed its residual tolerance")
    header = "HEAT3D_PSI_V1 " + " ".join(map(str, (*interiors, *lengths))) + "\n"
    fixed = output / "fixed-psi.txt"
    zero = output / "zero-psi.txt"
    with fixed.open("w") as target, raw.open() as source:
        target.write(header)
        shutil.copyfileobj(source, target)
    raw.unlink()
    with zero.open("w") as target:
        target.write(header)
        target.writelines("0\n" for _ in range(math.prod(interiors)))
    return fixed, zero, stats


def transport(command, output, label, geometry, config, psi, dt=None):
    field = output / (label + ".csv")
    args = [*command, *geometry, *config, "--fixed-psi", psi, "--output", field]
    if dt is not None:
        args += ["--dt", repr(dt)]
    run(args, output / (label + ".log"))
    return field, json.loads(field.with_suffix(".json").read_text())


def read_field(path, cells):
    nx, ny, nz = cells
    values = array("d")
    with path.open(newline="") as stream:
        for row in csv.reader(stream):
            if len(row) != nx:
                raise ValueError(f"expected {nx} cells per row in {path}")
            values.extend(map(float, row))
    if len(values) != nx * ny * nz or not all(map(math.isfinite, values)):
        raise ValueError(f"wrong shape or nonfinite concentration in {path}")
    if min(values) < -1e-12 or max(values) > 1.0 + 1e-12:
        raise ValueError(f"concentration outside the initial bounds in {path}")
    return values


def check_transport(summary, cells, lengths, dt, ranks=1, threads=1):
    if summary["flow"] != "fixed_3d_streamfunction" or summary["t_release"] != 0:
        raise RuntimeError("the fixed-flow input was not used")
    if summary["dt"] != dt or summary["mpi_ranks"] != ranks or summary["omp_threads"] != threads:
        raise RuntimeError("the run used a different timestep or MPI/OpenMP layout")
    advective_rate = (summary["u_max_measured"] * cells[0] / lengths[0]
                      + summary["v_max_measured"] * cells[1] / lengths[1])
    div_limit = 64 * sys.float_info.epsilon * max(1.0, advective_rate)
    if not 0 <= summary["max_discrete_divergence"] <= div_limit or summary["max_wall_normal_speed"] != 0:
        raise RuntimeError("the discrete velocity field violates divergence or wall checks")
    if not 0 <= summary["mass_error"] <= 1e-11:
        raise RuntimeError("the relative pigment mass change exceeds 1e-11")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cells", nargs=3, type=int, metavar=("NX", "NY", "NZ"), default=(33, 33, 33))
    parser.add_argument("--lengths", nargs=3, type=float, metavar=("LX", "LY", "LZ"), default=(1.0, 1.0, 1.0))
    parser.add_argument("--steps", type=int, default=50)
    parser.add_argument("--ranks", type=int, default=0, help="MPI transport ranks (default: serial only)")
    parser.add_argument("--threads", type=int, default=1, help="OpenMP threads per MPI rank")
    parser.add_argument("--exchange", choices=("blocking", "overlap"), default="blocking")
    parser.add_argument("--mpi-launcher", default="mpirun", help="launcher and flags, before -n RANKS")
    parser.add_argument("--output-dir", type=Path, help="new output directory (default: under results/)")
    args = parser.parse_args()
    interiors = tuple(n - 1 for n in args.cells)
    if min(interiors) < 1 or math.prod(interiors) > EXPORT_LIMIT:
        parser.error("use at least two cells per axis and at most 1,000,000 interior Poisson vertices")
    if any(not math.isfinite(length) or length <= 0 for length in args.lengths):
        parser.error("domain lengths must be positive and finite")
    if args.steps < 1 or args.threads < 1 or args.ranks < 0:
        parser.error("steps and threads must be positive, and ranks must be nonnegative")
    launcher = shlex.split(args.mpi_launcher)
    if args.ranks and not launcher:
        parser.error("an MPI run needs a nonempty launcher")

    output = configure_output(args.output_dir)
    print(f"Output directory: {output}", flush=True)
    binaries = build(output, args.ranks > 0)
    fixed, zero, poisson = generate_flow(binaries / "poisson3d_serial", output, interiors, args.lengths)

    geometry = geometry_flags(args.cells, args.lengths)
    config = ["--steps", str(args.steps), "--blob-x", repr(0.2 * args.lengths[0]),
              "--blob-y", repr(0.5 * args.lengths[1]), "--blob-width", repr(0.05 * min(args.lengths))]
    serial = [binaries / "heat3d_serial"]
    fixed_field, fixed_stats = transport(serial, output, "fixed-serial", geometry, config, fixed)
    dt = fixed_stats["dt"]
    check_transport(fixed_stats, args.cells, args.lengths, dt)
    concentration = read_field(fixed_field, args.cells)

    zero_field, zero_stats = transport(serial, output, "diffusion-serial", geometry, config, zero, dt)
    check_transport(zero_stats, args.cells, args.lengths, dt)
    diffusion = read_field(zero_field, args.cells)
    difference = max(abs(a - b) for a, b in zip(concentration, diffusion))
    summary = {
        "pigment_cells_xyz": args.cells, "poisson_interior_vertices_xyz": interiors,
        "lengths_xyz": args.lengths, "steps": args.steps, "dt": dt, "final_time": fixed_stats["t_end"],
        "poisson": poisson, "fixed_serial": fixed_stats, "diffusion_serial": zero_stats,
        "max_abs_fixed_vs_diffusion": difference,
    }
    if args.ranks:
        mpi = [*launcher, "-n", str(args.ranks), binaries / "heat3d_parallel", "--threads", str(args.threads),
               "--decomp", "pencils", "--exchange", args.exchange]
        mpi_field, mpi_stats = transport(mpi, output, "fixed-mpi", geometry, config, fixed, dt)
        check_transport(mpi_stats, args.cells, args.lengths, dt, args.ranks, args.threads)
        parallel = read_field(mpi_field, args.cells)
        error = max(abs(a - b) for a, b in zip(concentration, parallel))
        if error > 1e-12:
            raise RuntimeError(f"MPI concentration differs from serial by {error:.3g}")
        summary.update(fixed_mpi=mpi_stats, max_abs_serial_vs_mpi=error)
        print(f"Serial/MPI maximum concentration difference: {error:.3g}")

    report = output / "bridge-summary.json"
    report.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(f"Poisson relative residual: {poisson['relative_residual']:.3g}")
    print(f"Fixed-flow relative mass change: {fixed_stats['mass_error']:.3g}")
    print(f"Maximum concentration difference from pure diffusion: {difference:.3g}")
    print(f"Checks passed. Summary: {report}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"run_bridge: {error}. See the logs in the output directory.", file=sys.stderr)
        sys.exit(1)
