cmake_minimum_required(VERSION 3.16)
project(ModelAPoissonBridge LANGUAGES CXX)

set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
add_subdirectory(model_a)
if(HEAT2D_BUILD_TESTS)
    enable_testing()
endif()

add_executable(poisson3d_serial ../poisson3d_benchmark/poisson3d.cpp)
set_target_properties(poisson3d_serial PROPERTIES CXX_STANDARD 17 CXX_STANDARD_REQUIRED ON CXX_EXTENSIONS OFF)
if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(poisson3d_serial PRIVATE -ffp-contract=off)
endif()
